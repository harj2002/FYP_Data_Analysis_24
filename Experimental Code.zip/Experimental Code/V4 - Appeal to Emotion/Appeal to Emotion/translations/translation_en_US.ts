<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../../Program Files (x86)/Softbank Robotics/Choregraphe Suite 2.5/translations/behavior_1/behavior.xar" line="0"/>
            <source></source>
            <comment>Text</comment>
            <translation></translation>
        </message>
        <message>
            <source>LIAM AND HARJ</source>
            <comment>Text</comment>
            <translation type="obsolete">LIAM AND HARJ</translation>
        </message>
        <message>
            <source>Take one candy</source>
            <comment>Text</comment>
            <translation type="obsolete">Take one candy</translation>
        </message>
        <message>
            <source>Please take one candy but feel free not to</source>
            <comment>Text</comment>
            <translation type="obsolete">Please take one candy but feel free not to</translation>
        </message>
        <message>
            <source>Please take one candy, but feel free not to</source>
            <comment>Text</comment>
            <translation type="obsolete">Please take one candy, but feel free not to</translation>
        </message>
        <message>
            <source>It would make me happy if you took 1 piece of candy</source>
            <comment>Text</comment>
            <translation type="obsolete">It would make me happy if you took 1 piece of candy</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>hey! It would make me happy if you took 1 piece of candy</source>
            <comment>Text</comment>
            <translation type="unfinished">hey! It would make me happy if you took 1 piece of candy</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say (1)</name>
        <message>
            <location filename="../../../../../../../../../../Program Files (x86)/Softbank Robotics/Choregraphe Suite 2.5/translations/behavior_1/behavior.xar" line="0"/>
            <source></source>
            <comment>Text</comment>
            <translation></translation>
        </message>
    </context>
</TS>
